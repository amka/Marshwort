# Marshwort

Marshwort it's an document-based application which provides users abilities to translate text from one language to another.

It's powered by [Yandex.Translate API](http://api.yandex.ru/translate/).

## System requirements

* Mac OS X 10.7+